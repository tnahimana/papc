<div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="position-relative overflow-hidden h-100" style="min-height: 400px;">
                        <img class="position-absolute w-100 h-100 pt-5 pe-5" src="img/papc.jpg" alt="" style="object-fit: cover;">
                        <img class="position-absolute top-0 end-0 bg-white ps-2 pb-2" src="img/about-2.jpg" alt="" style="width: 200px; height: 200px;">
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="h-100">
                        <div class="d-inline-block rounded-pill bg-secondary text-primary py-1 px-3 mb-3" style="text-transform: capitalize">à propos de nous</div>
                        <h1 class="display-6 mb-5">Notre Engagement et Notre Histoire</h1>
                        <div class="bg-light border-bottom border-5 border-primary rounded p-4 mb-4">
                            <p class="text-dark mb-2">Face à ces défis, l’association à but non lucratif Promotion des Actions Paysannes au Congo (PAPC) a été fondée en 2012. Elle est enregistrée sous le numéro d’autorisation de fonctionnement 01/248/CAB/GOUPRO-SK/2012. L'objectif principal de PAPC est de contribuer à la réduction de la pauvreté, à la restauration de la dignité humaine et à l'amélioration des conditions de vie des populations congolaises touchées par les catastrophes naturelles et humaines.</p>
                            <span class="text-primary">NDAYISABA, Fondateur </span>
                        </div>
                        <p class="mb-5">Le siège de la PAPC est situé à Goma, dans la province du Nord-Kivu, tandis que son bureau administratif est stratégiquement situé à Uvira, dans la province du Sud-Kivu. Ce positionnement favorise une coordination et une mise en œuvre efficaces des projets de développement du PAPC dans la région, contribuant à des impacts positifs et à une croissance durable.</p>
                        <a class="btn btn-primary py-2 px-3 me-3" href="<?php if(Illuminate\Support\Str::after(url()->current(), url('/')) == '/about'): ?> # <?php else: ?> /about <?php endif; ?>">
                            En savoir plus
                            <div class="d-inline-flex btn-sm-square bg-white text-primary rounded-circle ms-2">
                                <i class="fa fa-arrow-right  <?php if(Illuminate\Support\Str::after(url()->current(), url('/')) == '/about'): ?> back-to <?php endif; ?>"></i>
                            </div>
                        </a>
                        <a class="btn btn-outline-primary py-2 px-3" href="/contact">
                            Contactez-nous
                            <div class="d-inline-flex btn-sm-square bg-primary text-white rounded-circle ms-2">
                                <i class="fa fa-arrow-right"></i>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH /Users/nahimana/Documents/workspace/papc/resources/views/components/about-layout.blade.php ENDPATH**/ ?>