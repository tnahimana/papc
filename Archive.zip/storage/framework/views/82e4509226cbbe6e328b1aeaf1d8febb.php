<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
            <div class="d-inline-block rounded-pill bg-secondary text-primary py-1 px-3 mb-3">Ce que nous faisons</div>
            <h1 class="display-6 mb-5">En savoir plus sur ce que nous faisons et impliquer</h1>
        </div>
        <div class="row g-4 justify-content-center">
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="service-item bg-white text-center h-100 p-4 p-xl-5">
                    <img class="img-fluid mb-4" src="img/icon-1.png" alt="">
                    <h4 class="mb-3">Éducation des enfants</h4>
                    <p class="mb-4">Notre mission est de donner aux enfants défavorisés les moyens d'accéder à une éducation de qualité, de développer leur potentiel et de construire un avenir meilleur. Nous sommes convaincus que chaque enfant mérite d'avoir la possibilité d'apprendre, de grandir et de s'épanouir. Grâce au soutien de la communauté et à des programmes durables, nous nous efforçons de briser le cycle de la pauvreté, un enfant scolarisé après l'autre.</p>
                    <a class="btn btn-outline-primary px-3" href="">
                        Apprendre encore plus
                        <div class="d-inline-flex btn-sm-square bg-primary text-white rounded-circle ms-2">
                            <i class="fa fa-arrow-right"></i>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="service-item bg-white text-center h-100 p-4 p-xl-5">
                    <img class="img-fluid mb-4" src="img/icon-2.png" alt="">
                    <h4 class="mb-3">Autonomisation des femmes</h4>
                    <p class="mb-4">L'autonomisation des femmes est essentielle pour construire une société équitable et durable. Notre ONG s'engage à renforcer les capacités des femmes à travers l'éducation, la formation, et l'accès aux ressources économiques. En valorisant leur potentiel, nous favorisons leur pleine participation au développement communautaire et à la prise de décision.</p>
                    <a class="btn btn-outline-primary px-3" href="">
                        Apprendre encore plus
                        <div class="d-inline-flex btn-sm-square bg-primary text-white rounded-circle ms-2">
                            <i class="fa fa-arrow-right"></i>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="service-item bg-white text-center h-100 p-4 p-xl-5">
                    <img class="img-fluid mb-4" src="img/icon-3.png" alt="">
                    <h4 class="mb-3">Eau potable pure</h4>
                    <p class="mb-4">L'accès à l'eau potable est vital pour la santé, mais de nombreuses communautés en sont encore privées. Notre ONG s'engage à fournir des solutions d'approvisionnement en eau propre, sûre et durable aux populations mal desservies. Grâce à des technologies innovantes, des partenariats communautaires et l'éducation, nous visons à améliorer les conditions de vie et à réduire les maladies d'origine hydrique pour un impact durable.</p>
                    <a class="btn btn-outline-primary px-3" href="">
                        Apprendre encore plus
                        <div class="d-inline-flex btn-sm-square bg-primary text-white rounded-circle ms-2">
                            <i class="fa fa-arrow-right"></i>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Users/nahimana/Documents/workspace/papc/resources/views/components/service-layout.blade.php ENDPATH**/ ?>