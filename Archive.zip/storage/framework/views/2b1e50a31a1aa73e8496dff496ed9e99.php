<?php $__env->startSection('home'); ?>
 active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>

    <!-- Carousel Start -->
    <div class="container-fluid p-0 mb-5">
        <div id="header-carousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="w-100" src="img/school.jpg" alt="Image">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-7 pt-5">
                                    <h1 class="display-4 text-white mb-3 animated slideInDown">Éduquer les jeunes pour un avenir radieux</h1>
                                    <p class="fs-5 text-white-50 mb-5 animated slideInDown">Doter la jeune génération des connaissances nécessaires pour bâtir un avenir prospère. L'éducation d'aujourd'hui ouvre la voie à un avenir meilleur et plus autonome.</p>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="w-100" src="img/change.jpg" alt="Image">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-7 pt-5">
                                    <h1 class="display-4 text-white mb-3 animated slideInDown">Changeons le monde avec l'humanité</h1>
                                    <p class="fs-5 text-white-50 mb-5 animated slideInDown">C’est l’humanité – notre capacité à nous connecter, à prendre soin et à nous encourager les uns les autres – qui transformera véritablement les vies et créera un avenir meilleur pour tous. Ensemble, exploitons nos valeurs communes pour construire un monde où la bienveillance et le progrès vont de pair.</p>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="w-100" src="img/water.jpg" alt="Image">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-7 pt-5">
                                    <h1 class="display-4 text-white mb-3 animated slideInDown">L'eau propre pour une vie meilleure</h1>
                                    <p class="fs-5 text-white-50 mb-5 animated slideInDown">L'eau potable est la clé d'une vie meilleure. Garantissons son accès à tous, favorisant ainsi la santé, l'espoir et un avenir meilleur.</p>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="w-100" src="img/environment.jpg" alt="Image">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-7 pt-5">
                                    <h1 class="display-4 text-white mb-3 animated slideInDown">Protéger notre environnement</h1>
                                    <p class="fs-5 text-white-50 mb-5 animated slideInDown">Préserver notre environnement est la garantie d'un avenir durable. Agissons dès maintenant pour préserver l'équilibre naturel pour les générations futures.</p>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#header-carousel"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#header-carousel"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
    <!-- Carousel End -->


    <!-- About Start -->
        <?php echo $__env->make('components.about-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- About End -->


    <!-- Causes Start -->
    <div class="container-xxl bg-light my-5 py-5">
        <div class="container py-5">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
                <div class="d-inline-block rounded-pill bg-secondary text-primary py-1 px-3 mb-3">Nos programmes</div>
                <h1 class="display-6 mb-5">Des Initiatives pour un Développement Durable</h1>
            </div>
            <div class="row g-4 justify-content-center">
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="causes-item d-flex flex-column bg-white border-top border-5 border-primary rounded-top overflow-hidden h-100">
                        <div class="text-center p-4 pt-0">
                            <div class="d-inline-block bg-primary text-white rounded-bottom fs-5 pb-1 px-3 mb-4">
                                <small>Éducation </small>
                            </div>
                            <h5 class="mb-3">Éducation pour les enfants congolais</h5>
                            <p>L’organisation PAPC a mis en place le complexe scolaire Isoko en 2005 dans la région de Minembwe (une zone isolée, enclavée et en proie à des conflits armés cycliques), en raison de la nécessité de créer une école dans cette région soulevée par les communautés de Minembwe. Dans leur plan de développement communautaire, ils ont mentionné que seulement 2% des enfants ont pu réussir leurs examens d’État.</p>
                            
                        </div>
                        <div class="position-relative mt-auto">
                            <img class="img-fluid" src="img/courses-1.jpg" alt="">
                            <div class="causes-overlay">
                                <a class="btn btn-outline-primary" href="">
                                    En savoir plus
                                    <div class="d-inline-flex btn-sm-square bg-primary text-white rounded-circle ms-2">
                                        <i class="fa fa-arrow-right"></i>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="causes-item d-flex flex-column bg-white border-top border-5 border-primary rounded-top overflow-hidden h-100">
                        <div class="text-center p-4 pt-0">
                            <div class="d-inline-block bg-primary text-white rounded-bottom fs-5 pb-1 px-3 mb-4">
                                <small>Eau, Assainissement et Hygiène</small>
                            </div>
                            <h5 class="mb-3">Garantir une eau potable pure</h5>
                            <p>12 877 personnes des camps de réfugiés de Lusenda et 18 892 d'Idjwi ont accès à l'eau potable grâce à la construction de 103 points d'eau et de 7 réservoirs d'eau de 30 mètres cubes chacun par PAPC. Ces efforts ont permis d'épargner à ces personnes des maladies d'origine hydrique et de leur éviter de longs déplacements à la recherche d'eau potable. De plus, PAPC a formé et mis en place 24 comités de gestion de l'eau, dont 14 à Idjwi et 10 à Lusenda, chacun composé de 5 membres.</p>
                            
                        </div>
                        <div class="position-relative mt-auto">
                            <img class="img-fluid" src="img/courses-2.jpg" alt="">
                            <div class="causes-overlay">
                                <a class="btn btn-outline-primary" href="">
                                    En savoir plus
                                    <div class="d-inline-flex btn-sm-square bg-primary text-white rounded-circle ms-2">
                                        <i class="fa fa-arrow-right"></i>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="causes-item d-flex flex-column bg-white border-top border-5 border-primary rounded-top overflow-hidden h-100">
                        <div class="text-center p-4 pt-0">
                            <div class="d-inline-block bg-primary text-white rounded-bottom fs-5 pb-1 px-3 mb-4">
                                <small>Santé et Bien-être</small>
                            </div>
                            <h5 class="mb-3">Assurer un traitement médical</h5>
                            <p>Depuis 2015, PAPC offre des soins curatifs, préventifs et promotionnels à Minembwe et Bibokoboko, en RD Congo. En 2024, une clinique mobile a été lancée dans le camp de déplacés de Rusayo, au Sud-Kivu. Les services incluent sensibilisation, planification familiale, consultations prénatales, accouchements assistés, dépistage du VIH et mobilisations communautaires. Grâce à trois structures locales, la population n’a plus à parcourir de longues distances, réduisant les risques d’agressions, enlèvements et violences.</p>
                            
                        </div>
                        <div class="position-relative mt-auto">
                            <img class="img-fluid" src="img/courses-3.jpg" alt="">
                            <div class="causes-overlay">
                                <a class="btn btn-outline-primary" href="">
                                    En savoir plus
                                    <div class="d-inline-flex btn-sm-square bg-primary text-white rounded-circle ms-2">
                                        <i class="fa fa-arrow-right"></i>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Causes End -->


    <!-- Service Start -->
        <?php echo $__env->make('components.savoir-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- Service End -->


    <!-- Donate Start -->
        <?php echo $__env->make('components.donate-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- Donate End -->


    <!-- Team Start -->
        <?php echo $__env->make('components.members-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- Team End -->


    <!-- Testimonial Start -->
        <?php echo $__env->make('components.testimony-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- Testimonial End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/papc/resources/views/home/index.blade.php ENDPATH**/ ?>