<!-- Gallery Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
            <div class="d-inline-block rounded-pill bg-secondary text-primary py-1 px-3 mb-3">Galerie</div>
            <h1 class="display-6 mb-5">Nos activités récentes</h1>
        </div>
        <div class="container">
            

            <div class="gallery-container">
                <div class="gallery-slider" id="gallerySlider">
                    <!-- Images will be added dynamically -->
                </div>
            </div>

            <div class="gallery-controls">
                <button class="btn btn-primary" id="prevBtn">Précédent</button>
                <button class="btn btn-primary" id="nextBtn">Suivant</button>
            </div>
        </div>
    </div>
</div>
<!-- Gallery End -->



<?php /**PATH /Users/nahimana/Documents/workspace/papc/resources/views/components/gallery-layout.blade.php ENDPATH**/ ?>