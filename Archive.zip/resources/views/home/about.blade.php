@extends('layout.app')

@section('about')
 active
@endsection

@section('section')
     <!-- Page Header Start -->
    <div class="container-fluid page-header mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container text-center">
            <h1 class="display-4 text-white animated slideInDown mb-4">À propos de nous</h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item"><a class="text-white" href="/">Acceuil</a></li>
                    <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                    <li class="breadcrumb-item text-primary active" aria-current="/about">À propos de nous</li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- Page Header End -->

    <!-- About Start -->
        @include('components.about-layout')
    <!-- About End -->


    <!-- Service Start -->
        @include('components.savoir-layout')
    <!-- Service End -->


    <!-- Team Start -->
    @include('components.members-layout')
    <!-- Team End -->

    <!-- Pertner Start -->
    @include('components.partners-layout')
    <!-- Pertner End -->

@endsection
