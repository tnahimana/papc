<div class="container-xxl py-5">
        <div class="container">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
                <div class="d-inline-block rounded-pill bg-secondary text-primary py-1 px-3 mb-3">Pour un Avenir Meilleur</div>
                <h1 class="display-6 mb-5">Notre Mission et Vision</h1>
            </div>
            <div class="row g-4 justify-content-center">
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item bg-white text-center h-100 p-4 p-xl-5">
                        <img class="img-fluid mb-4" src="img/vision.png" height="150" width="150" alt="">
                        <h4 class="mb-3">Notre Vision</h4>
                        <p class="mb-4">Promouvoir un environnement résilient pour les communautés du Kivu en Republique Democratique Du Congo.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="service-item bg-white text-center h-100 p-4 p-xl-5">
                        <img class="img-fluid mb-4" src="img/mission.png" height="150" width="150" alt="">
                        <h4 class="mb-3">Notre Mission</h4>
                        <p class="mb-4">Accompagner les communautés vers leur bien-être à travers l’agriculture durable, l’éducation, la santé et la consolidation de la paix.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="service-item bg-white text-center h-100 p-4 p-xl-5">
                        <img class="img-fluid mb-4" src="img/rayon.png" height="140" width="140" alt="">
                        <h4 class="mb-3">Rayon d'actions</h4>
                        <p class="mb-4">PAPC est active à l’Est de la République Démocratique du Congo. Nos actions s'étendent sur les moyens plateaux de Bibokoboko, les Hauts Plateaux de Minembwe, Idjwi, Goma, Masisi.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
