<div class="container-xxl py-5">
        <div class="container">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
                <div class="d-inline-block rounded-pill bg-secondary text-primary py-1 px-3 mb-3">Nos partenaires</div>
                <h6 class=" mb-5">Découvrez les organisations et institutions qui soutiennent notre mission et contribuent à l'impact positif de nos projets sur le terrain. Ensemble, nous faisons une différence durable.</h6>
            </div>
            <div class="row g-4">
                <div class="col-lg-2 col-md-4 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item position-relative rounded overflow-hidden">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/sodi.jpg" alt="">
                        </div>
                    </div>
                </div>
                 <div class="col-lg-2 col-md-4 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item position-relative rounded overflow-hidden">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/global.png" alt="">
                        </div>
                    </div>
                </div>
                 <div class="col-lg-2 col-md-4 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item position-relative rounded overflow-hidden">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/seco.png" alt="">
                        </div>
                    </div>
                </div>
                 <div class="col-lg-2 col-md-4 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item position-relative rounded overflow-hidden">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/helpp.png" alt="">
                        </div>
                    </div>
                </div>
                 <div class="col-lg-2 col-md-4 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item position-relative rounded overflow-hidden">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/vitol.jpg" alt="">
                        </div>
                    </div>
                </div>
                 <div class="col-lg-2 col-md-4 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item position-relative rounded overflow-hidden">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/gould.jpg" alt="">
                        </div>
                    </div>
                </div>
                {{-- <div class="col-lg-2 col-md-4-2 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item position-relative rounded overflow-hidden">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/segal.jpg" alt="">
                        </div>
                    </div>
                </div> --}}
            </div>
        </div>
    </div>
