  <!-- Testimonial Start -->
  <div class="container-xxl py-5">
    <div class="container">
        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
            <div class="d-inline-block rounded-pill bg-secondary text-primary py-1 px-3 mb-3">Témoignages</div>
            <h1 class="display-6 mb-5">Ce que Disent Nos Bénéficiaires</h1>
        </div>
        <div class="owl-carousel testimonial-carousel wow fadeInUp" data-wow-delay="0.1s">
            <div class="testimonial-item text-center">
                <img class="img-fluid bg-light rounded-circle p-2 mx-auto mb-4" src="img/refugee-1.jpeg" style="width: 100px; height: 100px;">
                <div class="testimonial-text rounded text-center p-4">
                    <p>J’ai bénéficié de la part le PAPC des intrants agricoles constitué des outils aratoires (une houe et un arrosoir),100gr des semences des cultures maraichères de différentes spéculations :  le chou, l’oignon, l’amarante et l’aubergine, en raison de 25gr par spéculation. UGEAFI a pris également un champ de 12 ares à mon nom pour effectuer des travaux champêtres avec ces cultures maraîchères.</p>
                    <h5 class="mb-1"> Nijimbere Nestor</h5>
                    <span class="fst-italic">Refugié</span>
                </div>
            </div>
            <div class="testimonial-item text-center">
                <img class="img-fluid bg-light rounded-circle p-2 mx-auto mb-4" src="img/refugee-2.png" style="width: 100px; height: 100px;">
                <div class="testimonial-text rounded text-center p-4">
                    <p>Je remercie beaucoup PAPC de m’avoir appuyé avec un kit d’intrants agricoles constitués de 100gr de semences de cultures maraîchères à savoir : le choux, l’aubergines, l’oignons et l’amarantes en raison de 25gr par spéculation, des outils aratoires et pour la prise en charge de la location d’une terre arable pour y effectuer des travaux champêtres.</p>
                    <h5 class="mb-1">Mayabo Simon</h5>
                    <span class="fst-italic">Refugié</span>
                </div>
            </div>
            <div class="testimonial-item text-center">
                <img class="img-fluid bg-light rounded-circle p-2 mx-auto mb-4" src="img/refugee-3.avif" style="width: 100px; height: 100px;">
                <div class="testimonial-text rounded text-center p-4">
                    <p>Je remercie énormément PAPC et son partenaire de fond SODI de m’avoir appuyé avec un kit de démarrage d’une valeur de 100$ constitué des articles divers. Avant l’assistance de l’UGEAFI j’avais une vie précaire, pourque mes enfants ne meurent pas de faim j’étais obligé de travailler journalièrement pour les comptes de familles d’accueil : soit cultiver les maniocs ou lessiver les vêtements pour eux.</p>
                    <h5 class="mb-1">Ndayishimiye Louise</h5>
                    <span class="fst-italic">Refugié</span>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Testimonial End -->
